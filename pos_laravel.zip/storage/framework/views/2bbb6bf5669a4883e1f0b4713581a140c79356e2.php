
<?php $__env->startSection('content'); ?>
    <!--begin::Content-->
    <!--begin::Row-->
    <div class="d-flex flex-column-fluid">
        <div class="container">
            
                    <!--begin::Mixed Widget 14-->
                    
                        <!--end::Header-->
                        <!--begin::Body-->
                        
                        <!--end::Body-->
                    
                    <!--end::Mixed Widget 14-->
                
                <div class="col">
                    <!--begin::Advance Table Widget 4-->
                    <div class="card card-custom card-stretch gutter-b">
                        <!--begin::Header-->
                        <div class="card-header border-0 py-5">
                            <h3 class="card-title align-items-start flex-column">
                                <span class="card-label font-weight-bolder text-dark">Data Transaksi Penjualan
                                    Terbaru</span>
                                <span class="text-muted mt-3 font-weight-bold font-size-sm">Rincian Transaksi Hari
                                    Ini</span>
                            </h3>
                        </div>
                        <!--end::Header-->
                        <!--begin::Body-->
                        <div class="card-body pt-0 pb-3">
                            <div class="tab-content">
                                <!--begin::Table-->
                                <div class="table-responsive">
                                    <table
                                        class="table table-head-custom table-head-bg table-borderless table-vertical-center">
                                        <thead>
                                            <tr class="text-left text-uppercase">
                                                <th style="min-width: 250px" class="pl-7">
                                                    <span class="text-dark-75">ID Cabang</span>
                                                </th>
                                                <th style="min-width: 100px">Total Pendapatan</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <?php $__currentLoopData = $tot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td>
                                                        <span
                                                            class="text-dark-75 font-weight-bolder d-block font-size-lg"><?php echo e($ab->id_cabang); ?></span>

                                                    </td>
                                                    <td>
                                                        <span
                                                            class="text-dark-75 font-weight-bolder d-block font-size-lg">Rp.
                                                            <?php echo e(number_format($ab->total)); ?></span>

                                                    </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <!--end::Table-->
                            </div>
                        </div>
                        <!--end::Body-->
                    </div>
                    <!--end::Advance Table Widget 4-->
                </div>
            </div>
        </div>
        <!--end::Row-->
        <!--end::Dashboard-->
    </div>
    <!--end::Container-->
    </div>
    <!--end::Entry-->
    </div>
    <!--end::Content-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pos_laravel\resources\views/dashboard.blade.php ENDPATH**/ ?>