
<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-column-fluid">
        <div class="container">
            <div class="card card-custom">
                <div class="card-header">
                    <div class="card-title">
                        <span class="card-icon">
                            <i class="flaticon2-supermarket text-primary"></i>
                        </span>
                        <h3 class="card-label">Users</h3>
                    </div>
                </div>
                <div class="card card-custom">
                    <div class="card-header">
                        <div class="card-title">
                            <h3 class="card-label"></h3>
                        </div>
                        <div class="card-toolbar">
                            <button type="button" class="btn btn-primary font-weight-bolder" data-bs-toggle="modal"
                                data-bs-target="#tambah_barang">
                                Tambah
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <!--begin: Datatable-->
                        <table class="table table-bordered table-hover table-checkable" id="datatable"
                            style="margin-top: 13px !important">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama</th>
                                    <th>Email</th>
                                    <th>Jenis Kelamin</th>
                                    <th>Id Cabang</th>
                                    <th>User Level</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $no = 1;
                                ?>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td style="width: auto"><?php echo e($a->name); ?></td>

                                        <td style="width: auto"><?php echo e($a->email); ?></td>
                                        <td style="width: auto">
                                            <?php if($a->jenis_kelamin == 'L'): ?>
                                                Laki-Laki
                                            <?php elseif($a->jenis_kelamin == 'P'): ?>
                                                Perempuan
                                            <?php endif; ?>
                                        </td>
                                        <td style="width: auto"><?php echo e($a->id_cabang); ?></td>
                                        <td style="width: auto">
                                            <?php if($a->user_level == 1): ?>
                                                Admin
                                            <?php elseif($a->user_level == 2): ?>
                                                Kasir
                                            <?php endif; ?>
                                        </td>
                                        <td style="text-align: center">
                                            <button type="button" class="btn btn-success" data-bs-toggle="modal"
                                                data-bs-target="#edit<?php echo e($a->id); ?>">Edit</button>
                                            <button type="button" class="btn btn-danger" data-toggle="modal"
                                                data-target="#delete<?php echo e($a->id); ?>">Delete</button>
                                        </td>
                                        <div class="modal fade" id="delete<?php echo e($a->id); ?>" tabindex="-1" role="dialog"
                                            aria-labelledby="deletemodal" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="deletemodal">Hapus User</h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p>Anda yakin ingin menghapus <?php echo e($a->name); ?></p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Close</button>
                                                        <a href="<?php echo e(url('delete_users/users', $a->id)); ?> "
                                                            class="btn btn-primary">Hapus</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal fade" id="edit<?php echo e($a->id); ?>" tabindex="-1" role="dialog"
                                            aria-labelledby="addNewDonaturLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Edit User</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <form action="/proses_edit_users" method="POST"
                                                        enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="modal-body">
                                                            <div class="card-body">
                                                                <div class="row">
                                                                    <div class="col-md-12">
                                                                        <div class="form-group">
                                                                            <label>ID <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text"
                                                                                class="form-control form-control-solid"
                                                                                placeholder="Generate Otomatis" readonly
                                                                                value="<?php echo e($a->id); ?>" name="id"
                                                                                id="id" />

                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-12">
                                                                        <div class="form-group">
                                                                            <label>Nama</label>
                                                                            <input type="text" class="form-control"
                                                                                placeholder="Nama Cabang" name="name"
                                                                                id="name" value="<?php echo e($a->name); ?>"
                                                                                required />
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-12">
                                                                        <div class="form-group">
                                                                            <label>Email</label>
                                                                            <input type="text" class="form-control"
                                                                                placeholder="Email" name="email"
                                                                                value="<?php echo e($a->email); ?>"
                                                                                id="email" required />
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-12">
                                                                        <div class="form-group">
                                                                            <label>Password</label>
                                                                            <input type="password" class="form-control"
                                                                                placeholder="Password" name="password"
                                                                                id="password" />
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-12">
                                                                        <div class="form-group">
                                                                            <label>Jenis Kelamin</label>
                                                                            <select class="custom-select form-control"
                                                                                name="jenis_kelamin" id="jenis_kelamin">
                                                                                <option selected="selected">
                                                                                    Pilih Jenis Kelamin
                                                                                </option>
                                                                                <?php $__currentLoopData = $jk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <option value="<?php echo e($ab); ?>"
                                                                                        <?php echo e($ab == $a->jenis_kelamin ? 'selected' : ''); ?>>
                                                                                        <?php if($ab == 'L'): ?>
                                                                                            Laki-Laki
                                                                                        <?php elseif($ab == 'P'): ?>
                                                                                            Perempuan
                                                                                        <?php endif; ?>
                                                                                    </option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-12">
                                                                        <div class="form-group">
                                                                            <label> ID Cabang </label>
                                                                            <select class="custom-select form-control"
                                                                                name="id_cabang" id="id_cabang">
                                                                                
                                                                                <?php $__currentLoopData = $cabang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <option value="<?php echo e($ab->id_cabang ?? 'Cabang Tidak ditemukan'); ?>"
                                                                                        <?php echo e($ab->id == $a->id_cabang ? 'selected' : ''); ?>>
                                                                                        <?php echo e($ab->nama_cabang); ?> -
                                                                                        <?php echo e($ab->alamat); ?>

                                                                                    </option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-12">
                                                                        <div class="form-group">
                                                                            <label>User Level</label>
                                                                            <select class="custom-select form-control"
                                                                                name="user_level" id="user_level">
                                                                                <option selected="selected">
                                                                                    Pilih User Level
                                                                                </option>
                                                                                <?php $__currentLoopData = $ul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <option value="<?php echo e($ab); ?>"
                                                                                        <?php echo e($ab == $a->user_level ? 'selected' : ''); ?>>
                                                                                        <?php if($ab == 1): ?>
                                                                                            Admin
                                                                                        <?php elseif($ab == 2): ?>
                                                                                            Kasir
                                                                                        <?php else: ?>
                                                                                            Super Level
                                                                                        <?php endif; ?>
                                                                                    </option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary"
                                                                        data-bs-dismiss="modal">Kembali</button>
                                                                    <button type="submit"
                                                                        class="btn btn-primary mr-2">Edit</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!--end: Datatable-->
                    </div>
                    <div class="modal fade" id="tambah_barang" tabindex="-1" aria-labelledby="exampleModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Tambah User</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <form action="/proses_add_users" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-body">
                                        <div class="card-body">
                                            <div class="row">
                                                
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label>Nama</label>
                                                        <input type="text" class="form-control" placeholder="Nama"
                                                            name="name" id="name" required />
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label>Email</label>
                                                        <input type="text" class="form-control" placeholder="Email"
                                                            name="email" id="email" required />
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label>Password</label>
                                                        <input type="password" class="form-control"
                                                            placeholder="Password" name="password" id="password"
                                                            required />
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label>Jenis Kelamin</label>
                                                        <select class="custom-select form-control" name="jenis_kelamin"
                                                            id="jenis_kelamin">
                                                            <option selected="selected">
                                                                Pilih Jenis Kelamin
                                                            </option>
                                                            <?php $__currentLoopData = $jk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($a); ?>">
                                                                    <?php if($a == 'L'): ?>
                                                                        Laki-Laki
                                                                    <?php elseif($a == 'P'): ?>
                                                                        Perempuan
                                                                    <?php endif; ?>
                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label> ID Cabang </label>
                                                        <select class="custom-select form-control" name="id_cabang"
                                                            id="id_cabang">
                                                            <option selected="selected" selected disabled>
                                                                Pilih Cabang
                                                            </option>
                                                            <?php $__currentLoopData = $cabang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($a->id); ?>">
                                                                    <?php echo e($a->nama_cabang); ?> -
                                                                    <?php echo e($a->alamat); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label>User Level</label>
                                                        <select class="custom-select form-control" name="user_level"
                                                            id="user_level">
                                                            <option selected="selected">
                                                                Pilih User Level
                                                            </option>
                                                            <?php $__currentLoopData = $ul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($a); ?>">
                                                                    <?php if($a == 1): ?>
                                                                        Admin
                                                                    <?php elseif($a == 2): ?>
                                                                        Kasir
                                                                    <?php else: ?>
                                                                        Super Level
                                                                    <?php endif; ?>
                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Kembali</button>
                                            <button type="submit" class="btn btn-primary mr-2">Tambah</button>
                                        </div>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pos_laravel\resources\views/users/index.blade.php ENDPATH**/ ?>